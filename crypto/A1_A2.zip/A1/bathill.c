#include <stdio.h>
#include <string.h>

void getValues(int* a, int* b, int* c, int* d, char di1[], char di2[])
{
    int p11 = 19, p12 = 7; //('T', 'H')
    int p21 = 7, p22 = 4;  //('H', 'E')

    int c11 = (int)di1[0] - 65 , c12 = (int)di1[1] - 65;
    int c21 = (int)di2[0] - 65, c22 = (int)di2[1] - 65;

    /*
      p11 = (c11*a + c12*c) % 26;
      p21 = (c21*a + c22*c) % 26;

      p12 = (c11*b + c12*d) % 26;
      p22 = (c21*a + c22*d) % 26;
     */

    int flag1 = 0;
    for(int i = 0; i < 26; i++)
    {
        for(int j = 0; j < 26; j++)
        {
            if(((c11*i + c12*j) % 26) == p11 && ((c21*i + c22*j) % 26) == p21)
            {
                *a = i;
                *c = j;
                flag1 = 1;
                break;
            }
        }
        if(flag1 == 1)
            break;
    }

    int flag2 = 0;
    for(int i = 0; i < 26; i++)
    {
        for(int j = 0; j < 26; j++)
        {
            if(((c11*i + c12*j) % 26) == p12 && ((c21*i + c22*j) % 26) == p22)
            {
                *b = i;
                *d = j;
                flag2 = 1;
                break;
            }
        }
        if(flag2 == 1)
            break;
    }
                
}

int main()
{
    char encryptedText[100000];
    scanf("%s", encryptedText);    

    char di1[3], di2[3];
    scanf("%s%s", di1, di2);

    //ASCII = 65 for 'A'

    /* 
      Inverse Key

       | a   b |
       | c   d |

     */
    int a = -1, b = -1, c = -1, d = -1;
    getValues(&a, &b, &c, &d, di1, di2);

    int encLen = strlen(encryptedText);
    if(encLen % 2 == 1)
    {
        encryptedText[encLen] = 'Z';
        encryptedText[encLen+1] = '\0';
    }

    for(int i = 0; i < strlen(encryptedText); i+=2)
    {
        int c1 = (int)encryptedText[i] - 65;
        int c2 = (int)encryptedText[i+1] - 65;

        int p1 = (a*c1 + c*c2) % 26;
        int p2 = (b*c1 + d*c2) % 26;

        printf("%c%c", (char)(p1+65), (char)(p2+65));
    }

    printf("\n");

    return 0;
}