#include <stdio.h>
#include <string.h>

int main()
{
    int N;
    scanf("%d", &N);

    int key[N];
    for(int i = 0; i < N; i++)
    {
        scanf("%d", &key[i]);
        key[i]--;
    }

    char encrypted_key[100000];
    scanf("%s", encrypted_key);

    char trash;
    scanf("%c", &trash);

    char plaintext[100000];
    scanf("%s", plaintext);

    int nRows = strlen(encrypted_key) / N;
    char trans_matrix[nRows][N];

    int p = 0;
    for(int i = 0; i < N; i++)
    {
        for(int j = 0; j < nRows; j++)
        {
            trans_matrix[j][i] = encrypted_key[p++];
        }
    }

    char vigenere_key[strlen(plaintext)];
    p = 0;
    for(int i = 0; i < nRows; i++)
    {
        for(int j = 0; j < N; j++)
        {
            vigenere_key[p++] = trans_matrix[i][key[j]];
        }
    }
    
    int q = 0;
    while(p < strlen(plaintext))
        vigenere_key[p++] = vigenere_key[q++];

    vigenere_key[p] = '\0';

    for(int i = 0; i < strlen(encrypted_key); i++)
        printf("%c", vigenere_key[i]);

    printf("\n");

    //ASCII=97 is for 'a'

    for(int i = 0; i < strlen(plaintext); i++)
    {
        int l1 = (int)plaintext[i] - 97;
        int l2 = (int)vigenere_key[i] - 97;
        l1 += l2;
        l1 %= 26;
        printf("%c", (char)(l1+97));
    }
    printf("\n");   

    return 0;
}