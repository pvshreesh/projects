#include <stdio.h>
#include <string.h>
#include <math.h>

int charToDec(char c)
{
    if(c >= 97)
        return (int)c - 87;
    else
        return (int)c - 48;
}

char decToHex(int dec)
{
    if(dec >= 10)
        return (char)(dec+87);
    else
        return (char)(dec+48);
}

int main()
{
    char ciphertext[(int)pow(10, 6) + 1];
    scanf("%s", ciphertext);

    int plainlen = (strlen(ciphertext) + 1)/2;
    char plaintext[plainlen];
    plaintext[0] = ciphertext[0];
    plaintext[plainlen-1] = ciphertext[strlen(ciphertext)-1];
    

    int i = 1;
    int j = 0;
    while(i < strlen(ciphertext)-1)
    {
        plaintext[i] = decToHex(charToDec(ciphertext[j++]) ^ (charToDec(ciphertext[j])));
        i++;
    }

    for(int k = 0; k < plainlen; k++)
        printf("%c", plaintext[k]);
    printf("\n");

    return 0;
}