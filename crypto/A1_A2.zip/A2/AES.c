#include <stdio.h>
#include <math.h>
int lim = (int)pow(2, 8) - 1;

char* S_Box[16][16] = {  
    {"63", "7C", "77", "7B", "F2", "6B", "6F", "C5", "30", "01", "67", "2B", "FE", "D7", "AB", "76"},  
    {"CA", "82", "C9", "7D", "FA", "59", "47", "F0", "AD", "D4", "A2", "AF", "9C", "A4", "72", "C0"},  
    {"B7", "FD", "93", "26", "36", "3F", "F7", "CC", "34", "A5", "E5", "F1", "71", "D8", "31", "15"},  
    {"04", "C7", "23", "C3", "18", "96", "05", "9A", "07", "12", "80", "E2", "EB", "27", "B2", "75"},  
    {"09", "83", "2C", "1A", "1B", "6E", "5A", "A0", "52", "3B", "D6", "B3", "29", "E3", "2F", "84"},  
    {"53", "D1", "00", "ED", "20", "FC", "B1", "5B", "6A", "CB", "BE", "39", "4A", "4C", "58", "CF"},  
    {"D0", "EF", "AA", "FB", "43", "4D", "33", "85", "45", "F9", "02", "7F", "50", "3C", "9F", "A8"},  
    {"51", "A3", "40", "8F", "92", "9D", "38", "F5", "BC", "B6", "DA", "21", "10", "FF", "F3", "D2"},  
    {"CD", "0C", "13", "EC", "5F", "97", "44", "17", "C4", "A7", "7E", "3D", "64", "5D", "19", "73"},  
    {"60", "81", "4F", "DC", "22", "2A", "90", "88", "46", "EE", "B8", "14", "DE", "5E", "0B", "DB"},  
    {"E0", "32", "3A", "0A", "49", "06", "24", "5C", "C2", "D3", "AC", "62", "91", "95", "E4", "79"},  
    {"E7", "C8", "37", "6D", "8D", "D5", "4E", "A9", "6C", "56", "F4", "EA", "65", "7A", "AE", "08"},  
    {"BA", "78", "25", "2E", "1C", "A6", "B4", "C6", "E8", "DD", "74", "1F", "4B", "BD", "8B", "8A"},  
    {"70", "3E", "B5", "66", "48", "03", "F6", "0E", "61", "35", "57", "B9", "86", "C1", "1D", "9E"},  
    {"E1", "F8", "98", "11", "69", "D9", "8E", "94", "9B", "1E", "87", "E9", "CE", "55", "28", "DF"},  
    {"8C", "A1", "89", "0D", "BF", "E6", "42", "68", "41", "99", "2D", "0F", "B0", "54", "BB", "16"}  
};

char* Rcon[10] = {"01000000", "02000000", "04000000", "08000000", "10000000",  
                 "20000000", "40000000", "80000000", "1B000000", "36000000"};

char* fixedMat[4][4] = {
                            {"02", "03", "01", "01"},
                            {"01", "02", "03", "01"},
                            {"01", "01", "02", "03"},
                            {"03", "01", "01", "02"},
                        }; 

char w[44][8];
char state[4][4][2];

int convertCharToDec(char c)
{   
    if(c >= 65)
        return (int)c - 55;
    else
        return (int)c - 48;
}

char convertDecToChar(int d)
{
    if(d >= 10)
        return (char)(d+55);
    else
        return (char)(d+48);
}

void rotWord(char temp[])
{
    for(int i = 0; i < 2; i++)
    {
        int tc = temp[0];

        for(int j = 1; j < 8; j++)
            temp[j-1] = temp[j];

        temp[7] = tc;
    }
}
void xorWordElements(char res[], char a[], char b[])
{
    for(int i = 0; i < 8; i++)
    {
        int l = convertCharToDec(a[i]);
        int r = convertCharToDec(b[i]);
        
        int x = l^r;
        res[i] = convertDecToChar(x);
    }
}

void subWord(char temp[])
{
    for(int i = 0; i < 8; i+=2)
    {
        int l = convertCharToDec(temp[i]);
        int r = convertCharToDec(temp[i+1]);
        temp[i] = S_Box[l][r][0];
        temp[i+1] = S_Box[l][r][1];
    }
}

void keyExpansion(char key[])
{
    char temp[8];
    for(int i = 0; i < 4; i++)
    {
        for(int j = 0; j < 8; j++)
        {
            w[i][j] = key[j + i*8];
        }
    }

    for(int i = 4; i < 44; i++)
    {
        for(int j = 0; j < 8; j++)
        {
            temp[j] = w[i-1][j];
        }

        if(i % 4 == 0)
        {
            rotWord(temp);
            subWord(temp);
            xorWordElements(temp, temp, Rcon[i/4 - 1]);
        }
        xorWordElements(w[i], w[i-4], temp);
    }
}

void addRoundKey(int round)
{
    char keyMat[4][4][2];
    int indi = 4*round;
    int indj = 0;
    for(int j = 0; j < 4; j++)
    {
        for(int i = 0; i < 4; i++)
        {
            keyMat[i][j][0] = w[indi][indj++];
            keyMat[i][j][1] = w[indi][indj++];
        }
        indi++;
        indj = 0;
    }

    for(int i = 0; i < 4; i++)
    {
        for(int j = 0; j < 4; j++)
        {
            int ls = convertCharToDec(state[i][j][0]);
            int rs = convertCharToDec(state[i][j][1]);

            int lk = convertCharToDec(keyMat[i][j][0]);
            int rk = convertCharToDec(keyMat[i][j][1]);

            int lres = ls^lk;
            int rres = rs^rk;

            state[i][j][0] = convertDecToChar(lres);
            state[i][j][1] = convertDecToChar(rres);
        }
    }
}

void subBytes()
{
    for(int i = 0; i < 4; i++)
    {
        for(int j = 0; j < 4; j++)
        {
            int l = convertCharToDec(state[i][j][0]);
            int r = convertCharToDec(state[i][j][1]);

            state[i][j][0] = S_Box[l][r][0];
            state[i][j][1] = S_Box[l][r][1];
        }
    }
}

void shiftRows()
{
    for(int i = 0; i < 4; i++)
    {
        for(int j = 0; j < i; j++)
        {
            int ltemp = state[i][0][0];
            int rtemp = state[i][0][1];
            for(int k = 0; k < 3; k++)
            {
                state[i][k][0] = state[i][k+1][0];
                state[i][k][1] = state[i][k+1][1];
            }
            state[i][3][0] = ltemp;
            state[i][3][1] = rtemp;
        }
    }
}

int convertHexToDec(char c[])
{
    int msb = convertCharToDec(c[0]);
    int lsb = convertCharToDec(c[1]);

    return (16*msb + lsb);
}

int multiply(char left[], char right[])
{
    int rleft = convertCharToDec(left[1]);
    if(rleft == 1)
        return convertHexToDec(right);
    else if(rleft == 2)
    {
        int dec = convertHexToDec(right);
        if(dec & (int)pow(2, 7))
        {
            dec = (dec << 1);
            dec = (dec & lim);
            dec ^= 27;
            return dec;
        }
        else
        {
            dec = (dec << 1);
            dec = (dec & lim);
            return dec;
        }
    }
    else if (rleft == 3)
    {
        int dec = convertHexToDec(right);
        int temp = dec;
        if(dec & (int)pow(2, 7))
        {
            dec = (dec << 1);
            dec = (dec & lim);
            dec ^= 27;
            dec ^= temp;
            return dec;
        }
        else
        {
            dec = (dec << 1);
            dec = (dec & lim);
            dec ^= temp;
            return dec;
        }
    }
}

void mixColumns()
{
    int final[4][4];
    for(int i = 0; i < 4; i++)
    {
        int res = 0;
        for(int j = 0; j < 4; j++)
        {
            final[i][j] = 0;
            for(int k = 0; k < 4; k++)
            {
                final[i][j] ^= multiply(fixedMat[i][k], state[k][j]);
            }
        }
    }

    for(int i = 0; i < 4; i++)
    {
        for(int j = 0; j < 4; j++)
        {
            int lsb = final[i][j] % 16;
            int msb = final[i][j] / 16;
            state[i][j][0] = convertDecToChar(msb);
            state[i][j][1] = convertDecToChar(lsb);
        }
    }
}

int main()
{
    char plaintext[33];
    char key[33];

    scanf("%s", plaintext);
    scanf("%s", key);

    keyExpansion(key);

    for(int i = 4; i < 44; i++)
    {        
        if(i % 4 == 0 && i != 4)
            printf("\n");

        for(int j = 0; j < 8; j++)
        {
            printf("%c", w[i][j]);
        }
    }
    printf("\n");

    int ind = 0;
    for(int j = 0; j < 4; j++)
    {
        for(int i = 0; i < 4; i++)
        {
            state[i][j][0] = plaintext[ind++];
            state[i][j][1] = plaintext[ind++];
        }
    }

    addRoundKey(0);

    for(int i = 1; i < 10; i++)
    {
        subBytes();
        shiftRows();
        mixColumns();
        addRoundKey(i);
    }

    subBytes();
    shiftRows();
    addRoundKey(10);

    for(int i = 0; i < 4; i++)
    {
        for(int j = 0; j < 4; j++)
        {
            printf("%c%c", state[j][i][0], state[j][i][1]);
        }
    }
    printf("\n");
    

    return 0;
}

/* INPUT
54776F204F6E65204E696E652054776F
5468617473206D79204B756E67204675


OUTPUT
E232FCF191129188B159E4E6D679A293
56082007C71AB18F76435569A03AF7FA
D2600DE7157ABC686339E901C3031EFB
A11202C9B468BEA1D75157A01452495B
B1293B3305418592D210D232C6429B69
BD3DC287B87C47156A6C9527AC2E0E4E
CC96ED1674EAAA031E863F24B2A8316A
8E51EF21FABB4522E43D7A0656954B6C
BFE2BF904559FAB2A16480B4F7F1CBD8
28FDDEF86DA4244ACCC0A4FE3B316F26
29C3505F571420F6402299B31A02D73A
*/