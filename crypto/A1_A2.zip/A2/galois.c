#include <stdio.h>
#include <math.h>
#define ulong unsigned long

int convertToDec(ulong b)
{
    int dec = 0;
    int exp = 0;
    while(b != 0)
    {
        dec += (int)pow(2, exp)*(b%10);
        b /= 10;
        exp++;
    }
    return dec;
}

int getBinLen(int val)
{
    int len = 0;
    int rem = 1;
    while(1)
    {
        if(val == val%rem)
            break;

        len++;
        rem *= 2;
    }

    return len;
}

int multiply(int f, int g)
{
   int glen = getBinLen(g);
   
   int res = 0;
   for(int i = 0; i < glen; i++)
   {
        if(g & 1)
            res ^= f;

        g = (g >> 1);
        f = (f << 1);
   }

   return res;
}

int main()
{
    ulong fbits, gbits, mbits;
    scanf("%lu", &fbits);
    scanf("%lu", &gbits);
    scanf("%lu", &mbits);

    int f, g, m;
    f = convertToDec(fbits);
    g = convertToDec(gbits);
    m = convertToDec(mbits);

    int fxg = multiply(f, g);
    int fxgLen = getBinLen(f) + getBinLen(g) - 1;
    int modLen = getBinLen(m);

    while(1)
    {
        int isDiv = 0;
        for(int i = modLen-1; i < fxgLen; i++)
        {
            if((fxg >> i) & 1)
            {
                isDiv = 1;
                break;
            }
        }

        if(isDiv)
        {
            for(int i = fxgLen-1; i >= 0; i--)
            {
                if((fxg >> i) & 1)
                {
                    int sub = (m << (i - modLen + 1));
                    fxg ^= sub;
                    break;
                }
            }
        }
        else
            break;
    }

    int resLen = getBinLen(fxg);
    for(int i = resLen-1; i>= 0; i--)
        printf("%d", (fxg >> i) & 1);

    printf("\n");

    return 0;
}