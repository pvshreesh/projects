import pickle
import os

time_lst = []
pickle.dump(time_lst, open('./brainpoolP192r1.pickle','wb'))

