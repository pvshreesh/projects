import os
import pickle

time_lst = pickle.load(open('./brainpoolP192r1.pickle','rb'))
time_lst_2 = pickle.load(open('./brainpoolP192r1.pickle','rb'))

# time